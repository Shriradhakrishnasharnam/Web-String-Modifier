ua-parser.min.js:
  https://github.com/Shriradhakrishnasharnam/Web-String-Modifier/
